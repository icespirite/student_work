#pragma once

#include "player.h"
// ����
class Sheep : public Player
{
public:
	Sheep(int n) : Player(n) {}
	void step();
};