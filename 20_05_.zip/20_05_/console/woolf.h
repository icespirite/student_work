#pragma once
#include "player.h"
// ����
class Woolf : public Player
{
public:
	Woolf(int n) : Player(n) {}
	int step();
};