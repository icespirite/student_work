#include "koord.h"

int Koord::i=0;
int Koord::j=0;